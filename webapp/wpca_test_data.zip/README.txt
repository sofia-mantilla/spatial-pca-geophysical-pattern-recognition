MOCK DATASET for testing wPCA Explorer's "Upload your own data"
================================================================

Synthetic 50 x 35 km survey, 100 m cells, EPSG:32722 (UTM 22S), top-left
corner at E 500,000 / N 8,000,000. All anomalies are invented.

Files
-----
MAG.tif           Magnetic-style variable (nT). Float32 GeoTIFF, uncompressed,
                  nodata = -99999 (upper-left corner is masked to test gaps).
RAD.tif           Radiometric-style variable (ppm). Same grid.
GRAV.tif          Gravity-style variable (mGal, smoothed inverse of MAG). Same grid.
deposits.geojson  7 deposit outlines with a "name" property (load this one).
deposits.zip      Same outlines as a zipped shapefile (for future support).

Suggested test
--------------
1. Upload MAG.tif as Variable 1, RAD.tif as Variable 2 (optional),
   deposits.geojson as outlines. Load the dataset.
2. Keep D1 Big Dipole as the reference and run.

What to expect
--------------
D2 Twin, D3 Cousin and D6 Echo carry the same dipole-style signature as D1
and should be recovered early. D4 Rad Cap is radiometric-dominant (multivariate
with some weight on RAD helps). D5 Whisper is weak; D7 Oddball is a strong but
round magnetic blob that a good geometry match should NOT rank early. Three
decoy anomalies have no deposit outlines - windows there count as area but
never as recovery.
